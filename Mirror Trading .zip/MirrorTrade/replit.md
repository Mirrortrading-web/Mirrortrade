# Mirror Trading Investment Platform

## Overview

Mirror Trading is a full-stack investment platform that allows users to mirror successful traders, purchase investment courses, and participate in an affiliate program. The application features a React frontend with TypeScript, an Express.js backend, PostgreSQL database with Drizzle ORM, and integrates Replit's authentication system.

**Current Status (January 2025)**: Fully functional MVP with authenticated users, real portfolio data, course marketplace with 5 educational courses, admin panel, and black/gold themed professional UI. Database populated with sample trading data including stocks (AAPL, TSLA, MSFT, GOOGL) and cryptocurrency holdings (BTC, ETH).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with Neon serverless PostgreSQL
- **Authentication**: Replit OpenID Connect integration
- **Session Management**: Express sessions with PostgreSQL storage

### Database Design
- **Primary Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle with type-safe schema definitions
- **Migrations**: Drizzle Kit for schema management
- **Session Storage**: PostgreSQL table for session persistence

## Key Components

### Authentication System
- **Provider**: Replit OpenID Connect
- **Session Storage**: PostgreSQL with connect-pg-simple
- **User Management**: Automatic user creation/updates via OIDC claims
- **Admin Access**: Role-based access control with admin privileges

### Database Schema
- **Users**: Profile data, KYC status, financial balances, admin flags
- **Portfolios**: User investment portfolios with asset tracking
- **Courses**: Educational content marketplace with pricing
- **Transactions**: Financial transaction history
- **Support Tickets**: Customer service system
- **KYC Documents**: Identity verification file storage
- **Course Purchases**: Purchase tracking and access control

### API Structure
- **RESTful Endpoints**: Express routes for CRUD operations
- **Authentication Middleware**: Replit auth integration
- **Error Handling**: Centralized error management
- **Request Logging**: Development request/response logging

### UI Components
- **Design System**: shadcn/ui components with custom theming
- **Responsive Design**: Mobile-first approach with breakpoint utilities
- **Dark Theme**: Financial platform aesthetic with gold accents
- **Interactive Charts**: Trading performance visualization
- **Form Validation**: Real-time validation with error feedback

## Data Flow

### Authentication Flow
1. User initiates login via Replit OAuth
2. Backend validates OIDC tokens and creates/updates user
3. Session established with PostgreSQL storage
4. Frontend receives authenticated user data
5. Protected routes accessible based on authentication state

### Investment Platform Flow
1. Authenticated users access dashboard with portfolio overview
2. Real-time trading charts display performance metrics
3. Course marketplace allows browsing and purchasing content
4. Affiliate system tracks referrals and earnings
5. KYC verification enables full platform access
6. Support system handles user inquiries

### Admin Management Flow
1. Admin users access specialized admin panel
2. User management with balance adjustments
3. KYC document review and approval workflow
4. Support ticket management and resolution
5. Course content management and pricing

## External Dependencies

### Development Tools
- **Vite**: Frontend build tool and dev server
- **TypeScript**: Type safety across frontend and backend
- **Tailwind CSS**: Utility-first styling framework
- **ESBuild**: Backend bundling for production

### Database & Storage
- **Neon**: Serverless PostgreSQL database
- **Drizzle ORM**: Type-safe database interactions
- **WebSocket**: Database connection via ws library

### UI Libraries
- **Radix UI**: Headless component primitives
- **TanStack Query**: Server state management
- **React Hook Form**: Form state and validation
- **Recharts**: Chart visualization components

### Authentication
- **OpenID Client**: OIDC protocol implementation
- **Passport**: Authentication middleware
- **Express Session**: Session management

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with Express backend
- **Hot Reload**: Automatic frontend updates during development
- **Database**: Neon serverless PostgreSQL connection
- **Environment Variables**: DATABASE_URL, REPLIT_DOMAINS, SESSION_SECRET

### Production Build
- **Frontend**: Static build output via Vite
- **Backend**: ESBuild bundling for Node.js deployment
- **Static Serving**: Express serves frontend build in production
- **Database Migrations**: Drizzle Kit schema deployment

### Configuration Management
- **Environment Variables**: Database URL, session secrets, OAuth config
- **Database Schema**: Version-controlled migrations
- **TypeScript Paths**: Shared types between frontend and backend
- **Build Scripts**: Automated development and production workflows

The architecture prioritizes type safety, developer experience, and scalable deployment while maintaining separation of concerns between frontend presentation, backend business logic, and data persistence layers.

## Recent Changes (January 2025)

✓ **Database Integration**: Successfully migrated from memory storage to PostgreSQL with Drizzle ORM
✓ **Sample Data Population**: Added realistic trading portfolio, investment courses, and transaction history
✓ **TypeScript Enhancement**: Fixed all type safety issues across frontend components
✓ **Authentication System**: Fully functional Replit Auth with admin access controls
✓ **UI/UX Polish**: Professional black and gold theme optimized for investment platform branding
✓ **Feature Completeness**: All core features operational including portfolio tracking, course marketplace, KYC verification, support tickets, and admin panel

## User Feedback
- Platform design and functionality confirmed as working well
- Professional appearance suitable for investment platform
- Navigation and user experience meeting expectations