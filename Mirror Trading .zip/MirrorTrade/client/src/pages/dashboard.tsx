import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import PortfolioStats from "@/components/dashboard/portfolio-stats";
import TradingChart from "@/components/dashboard/trading-chart";
import CourseMarketplace from "@/components/dashboard/course-marketplace";
import AffiliateProgram from "@/components/dashboard/affiliate-program";
import KycVerification from "@/components/dashboard/kyc-verification";
import SupportCenter from "@/components/dashboard/support-center";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-dark-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-gold border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      <Navbar user={user} />
      
      <div className="flex">
        <Sidebar />
        
        {/* Main Dashboard Content */}
        <div className="flex-1 p-6 pb-20 lg:pb-6">
          {/* Welcome Header */}
          <div className="mb-8 animate-fade-in">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Welcome back, <span className="text-gold">{user.firstName || 'Trader'}</span>
                </h1>
                <p className="text-gray-400 mt-2">Track your investments and grow your wealth with Mirror Trading</p>
              </div>
            </div>
          </div>

          {/* Portfolio Statistics */}
          <PortfolioStats user={user} />

          {/* Trading Charts */}
          <TradingChart />

          {/* Course Marketplace */}
          <CourseMarketplace />

          {/* Affiliate Program */}
          <AffiliateProgram user={user} />

          {/* KYC Verification */}
          <KycVerification user={user} />

          {/* Support Center */}
          <SupportCenter />
        </div>
      </div>

      {/* Mobile Navigation */}
      <MobileNav />
    </div>
  );
}
