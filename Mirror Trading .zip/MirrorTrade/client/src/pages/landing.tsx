import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      {/* Navigation */}
      <nav className="bg-black border-b border-dark-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <span className="text-2xl font-bold text-gold">Mirror Trading</span>
            </div>
            <Button onClick={handleLogin} className="bg-gold text-black hover:bg-gold-dark animate-pulse-gold">
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
              Professional <span className="text-gold">Investment Platform</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-400 mb-8 max-w-3xl mx-auto animate-slide-up">
              Mirror successful traders, learn from experts, and grow your wealth with our comprehensive investment platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <Button 
                onClick={handleLogin} 
                size="lg" 
                className="bg-gold text-black hover:bg-gold-dark text-lg px-8 py-4 animate-pulse-gold"
              >
                Start Trading Now
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-gold text-gold hover:bg-gold hover:text-black text-lg px-8 py-4"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-dark-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Mirror Trading?</h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Our platform combines cutting-edge technology with proven investment strategies
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-dark-bg border-dark-border hover:border-gold transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-gold bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
                <CardTitle className="text-white">Mirror Trading</CardTitle>
                <CardDescription className="text-gray-400">
                  Follow and copy successful traders automatically with our advanced mirror trading system.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-dark-bg border-dark-border hover:border-gold transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-500 bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                </div>
                <CardTitle className="text-white">Crypto & Traditional Assets</CardTitle>
                <CardDescription className="text-gray-400">
                  Trade cryptocurrencies, stocks, and other assets all in one secure platform.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-dark-bg border-dark-border hover:border-gold transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-500 bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                  </svg>
                </div>
                <CardTitle className="text-white">Educational Courses</CardTitle>
                <CardDescription className="text-gray-400">
                  Learn from expert traders with our comprehensive course marketplace.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-dark-bg border-dark-border hover:border-gold transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-green-500 bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <CardTitle className="text-white">Affiliate Program</CardTitle>
                <CardDescription className="text-gray-400">
                  Earn commissions by referring others to our platform with competitive rates.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-dark-bg border-dark-border hover:border-gold transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-500 bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <CardTitle className="text-white">Secure & Regulated</CardTitle>
                <CardDescription className="text-gray-400">
                  Bank-level security with full KYC compliance and regulatory oversight.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-dark-bg border-dark-border hover:border-gold transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-yellow-500 bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M12 2.944l7.071 7.071-7.071 7.071-7.071-7.071L12 2.944z" />
                  </svg>
                </div>
                <CardTitle className="text-white">24/7 Support</CardTitle>
                <CardDescription className="text-gray-400">
                  Round-the-clock customer support to help you with any questions or issues.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20 bg-dark-bg">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Your Investment Journey?
          </h2>
          <p className="text-xl text-gray-400 mb-8">
            Join thousands of successful traders and investors on our platform.
          </p>
          <Button 
            onClick={handleLogin} 
            size="lg" 
            className="bg-gold text-black hover:bg-gold-dark text-lg px-12 py-4 animate-pulse-gold"
          >
            Get Started Today
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black border-t border-dark-border py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="text-2xl font-bold text-gold mb-4 block">Mirror Trading</span>
            <p className="text-gray-400">© 2025 Mirror Trading. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
