import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { User, KycDocument } from "@shared/schema";

interface KycVerificationProps {
  user: User;
}

export default function KycVerification({ user }: KycVerificationProps) {
  const { toast } = useToast();
  const [documentType, setDocumentType] = useState<string>("");
  const [documentFile, setDocumentFile] = useState<File | null>(null);

  const { data: kycDocuments = [] } = useQuery<KycDocument[]>({
    queryKey: ["/api/kyc/documents"],
  });

  const uploadDocumentMutation = useMutation({
    mutationFn: async (documentData: { documentType: string; documentUrl: string }) => {
      await apiRequest("POST", "/api/kyc/documents", documentData);
    },
    onSuccess: () => {
      toast({
        title: "Document Uploaded",
        description: "Your KYC document has been submitted for review.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/kyc/documents"] });
      setDocumentType("");
      setDocumentFile(null);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Upload Failed",
        description: "Failed to upload document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDocumentUpload = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!documentType || !documentFile) {
      toast({
        title: "Missing Information",
        description: "Please select a document type and file.",
        variant: "destructive",
      });
      return;
    }

    // In a real app, you would upload the file to a storage service first
    // For this demo, we'll use a placeholder URL
    const mockDocumentUrl = `https://example.com/documents/${documentFile.name}`;
    
    uploadDocumentMutation.mutate({
      documentType,
      documentUrl: mockDocumentUrl,
    });
  };

  const kycStatus = user.kycStatus || "pending";
  const hasIdDocument = kycDocuments.some((doc: any) => doc.documentType === "id");
  const hasAddressProof = kycDocuments.some((doc: any) => doc.documentType === "address_proof");
  const isVerified = kycStatus === "approved";

  return (
    <div className="mb-8">
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold text-white">KYC Verification</CardTitle>
            <Badge 
              variant={isVerified ? "default" : kycStatus === "pending" ? "secondary" : "destructive"}
              className={
                isVerified ? "bg-green-500 text-white" :
                kycStatus === "pending" ? "bg-yellow-500 text-black" :
                "bg-red-500 text-white"
              }
            >
              {kycStatus === "approved" ? "Verified" : kycStatus}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-dark-bg border border-dark-border rounded-lg p-6 text-center">
              <div className={`w-16 h-16 ${hasIdDocument ? 'bg-green-500' : 'bg-gray-500'} bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4`}>
                <svg className={`w-8 h-8 ${hasIdDocument ? 'text-green-500' : 'text-gray-500'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V4a2 2 0 114 0v2m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h3m-3 4h3m-6-4h.01M9 16h.01" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Identity Verification</h3>
              <p className="text-gray-400 text-sm mb-4">Government-issued ID upload</p>
              <span className={`${hasIdDocument ? 'text-green-400' : 'text-gray-400'} font-medium`}>
                {hasIdDocument ? "✓ Completed" : "Pending"}
              </span>
            </div>

            <div className="bg-dark-bg border border-dark-border rounded-lg p-6 text-center">
              <div className={`w-16 h-16 ${hasAddressProof ? 'bg-green-500' : 'bg-gray-500'} bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4`}>
                <svg className={`w-8 h-8 ${hasAddressProof ? 'text-green-500' : 'text-gray-500'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Address Verification</h3>
              <p className="text-gray-400 text-sm mb-4">Proof of address document</p>
              <span className={`${hasAddressProof ? 'text-green-400' : 'text-gray-400'} font-medium`}>
                {hasAddressProof ? "✓ Completed" : "Pending"}
              </span>
            </div>

            <div className="bg-dark-bg border border-dark-border rounded-lg p-6 text-center">
              <div className={`w-16 h-16 ${isVerified ? 'bg-green-500' : 'bg-gray-500'} bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4`}>
                <svg className={`w-8 h-8 ${isVerified ? 'text-green-500' : 'text-gray-500'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Account Status</h3>
              <p className="text-gray-400 text-sm mb-4">Full platform access</p>
              <span className={`${isVerified ? 'text-green-400' : 'text-gray-400'} font-medium`}>
                {isVerified ? "✓ Active" : "Pending Review"}
              </span>
            </div>
          </div>

          {!isVerified && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-white mb-4">Upload Documents</h3>
              <form onSubmit={handleDocumentUpload} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="documentType" className="text-gray-400">Document Type</Label>
                    <Select value={documentType} onValueChange={setDocumentType}>
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue placeholder="Select document type" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="id">Government ID</SelectItem>
                        <SelectItem value="address_proof">Proof of Address</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="documentFile" className="text-gray-400">Document File</Label>
                    <Input
                      id="documentFile"
                      type="file"
                      accept=".jpg,.jpeg,.png,.pdf"
                      onChange={(e) => setDocumentFile(e.target.files?.[0] || null)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>
                <Button 
                  type="submit" 
                  className="bg-gold text-black hover:bg-gold-dark"
                  disabled={uploadDocumentMutation.isPending}
                >
                  {uploadDocumentMutation.isPending ? "Uploading..." : "Upload Document"}
                </Button>
              </form>
            </div>
          )}

          {isVerified ? (
            <div className="p-4 bg-green-500 bg-opacity-10 border border-green-500 rounded-lg">
              <div className="flex items-center">
                <svg className="w-5 h-5 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-green-400">Your account is fully verified. You have access to all platform features including deposits, withdrawals, and trading.</p>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-yellow-500 bg-opacity-10 border border-yellow-500 rounded-lg">
              <div className="flex items-center">
                <svg className="w-5 h-5 text-yellow-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
                <p className="text-yellow-400">Please complete your KYC verification to access all platform features.</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
