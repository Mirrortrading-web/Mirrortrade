import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

interface AffiliateProgramProps {
  user: User;
}

export default function AffiliateProgram({ user }: AffiliateProgramProps) {
  const { toast } = useToast();
  
  // Generate referral link (mock for demo)
  const referralLink = `https://mirrortrading.com/ref/${user.referralCode || user.id}`;
  
  // Mock affiliate stats
  const totalReferrals = 47;
  const activeReferrals = 34;
  const affiliateEarnings = parseFloat(user.affiliateEarnings || "0");
  const monthlyAffiliateEarnings = affiliateEarnings * 0.2; // Mock 20% of total as monthly

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink).then(() => {
      toast({
        title: "Copied!",
        description: "Referral link copied to clipboard.",
      });
    });
  };

  return (
    <div className="mb-8">
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-white">Affiliate Program</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="bg-dark-bg border border-dark-border rounded-lg p-6 mb-6">
                <h3 className="text-lg font-semibold text-white mb-4">Your Referral Stats</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-400 text-sm">Total Referrals</p>
                    <p className="text-2xl font-bold text-gold">{totalReferrals}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Active Referrals</p>
                    <p className="text-2xl font-bold text-green-400">{activeReferrals}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Total Earnings</p>
                    <p className="text-2xl font-bold text-white">
                      ${affiliateEarnings.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">This Month</p>
                    <p className="text-2xl font-bold text-gold">
                      ${monthlyAffiliateEarnings.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-dark-bg border border-dark-border rounded-lg p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Referral Link</h3>
                <div className="flex">
                  <Input
                    type="text"
                    value={referralLink}
                    readOnly
                    className="flex-1 bg-gray-800 border-gray-600 text-white rounded-r-none"
                  />
                  <Button
                    className="bg-gold text-black hover:bg-gold-dark rounded-l-none"
                    onClick={copyReferralLink}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                    </svg>
                  </Button>
                </div>
                <p className="text-gray-400 text-sm mt-2">Earn 15% commission on all referred user investments</p>
              </div>
            </div>

            <div className="bg-dark-bg border border-dark-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Commission Structure</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                  <div>
                    <p className="text-white font-medium">Direct Referrals</p>
                    <p className="text-gray-400 text-sm">Level 1 Commission</p>
                  </div>
                  <span className="text-gold font-bold">15%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                  <div>
                    <p className="text-white font-medium">Secondary Referrals</p>
                    <p className="text-gray-400 text-sm">Level 2 Commission</p>
                  </div>
                  <span className="text-gold font-bold">5%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                  <div>
                    <p className="text-white font-medium">Course Sales</p>
                    <p className="text-gray-400 text-sm">Educational Content</p>
                  </div>
                  <span className="text-gold font-bold">25%</span>
                </div>
              </div>
              <Button className="w-full bg-gold text-black hover:bg-gold-dark mt-4">
                Request Payout
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
