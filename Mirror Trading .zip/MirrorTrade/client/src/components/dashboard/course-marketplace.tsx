import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Course } from "@shared/schema";

export default function CourseMarketplace() {
  const { toast } = useToast();

  const { data: courses = [], isLoading } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const purchaseCourseMutation = useMutation({
    mutationFn: async (courseData: { courseId: string; purchasePrice: string }) => {
      await apiRequest("POST", "/api/courses/purchase", courseData);
    },
    onSuccess: () => {
      toast({
        title: "Course Purchased!",
        description: "You now have access to this course.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/courses/purchased"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Purchase Failed",
        description: "Failed to purchase course. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePurchase = (course: Course) => {
    purchaseCourseMutation.mutate({
      courseId: course.id,
      purchasePrice: course.price.toString(),
    });
  };

  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Investment Courses</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="bg-dark-card border-dark-border">
              <div className="w-full h-48 bg-gray-800 animate-pulse rounded-t-lg"></div>
              <CardContent className="p-6">
                <div className="h-4 bg-gray-800 rounded mb-2"></div>
                <div className="h-6 bg-gray-800 rounded mb-4"></div>
                <div className="h-4 bg-gray-800 rounded mb-4"></div>
                <div className="flex items-center justify-between">
                  <div className="h-6 w-16 bg-gray-800 rounded"></div>
                  <div className="h-10 w-24 bg-gray-800 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white">Investment Courses</h2>
        <Button variant="ghost" className="text-gold hover:text-gold-dark">
          View All 
          <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-dark-card rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No Courses Available</h3>
            <p className="text-gray-400">Check back soon for new educational content.</p>
          </div>
        ) : (
          courses.map((course: any) => (
            <Card key={course.id} className="bg-dark-card border-dark-border hover:border-gold transition-colors">
              <div className="w-full h-48 bg-gradient-to-br from-gold/20 to-transparent rounded-t-lg flex items-center justify-center">
                <svg className="w-16 h-16 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge 
                    variant="secondary"
                    className={
                      course.level === 'advanced' ? 'bg-gold text-black' :
                      course.level === 'intermediate' ? 'bg-purple-500 text-white' :
                      'bg-blue-500 text-white'
                    }
                  >
                    {course.level}
                  </Badge>
                  <div className="flex items-center">
                    <svg className="w-4 h-4 text-gold" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                    <span className="text-gray-400 ml-1 text-sm">
                      {parseFloat(course.rating || "0").toFixed(1)}
                    </span>
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{course.title}</h3>
                <p className="text-gray-400 text-sm mb-4 line-clamp-3">{course.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-gold font-bold text-lg">
                    ${parseFloat(course.price).toFixed(0)}
                  </span>
                  <Button 
                    className="bg-gold text-black hover:bg-gold-dark"
                    onClick={() => handlePurchase(course)}
                    disabled={purchaseCourseMutation.isPending}
                  >
                    {purchaseCourseMutation.isPending ? "Purchasing..." : "Purchase Course"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
