import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Chart } from "@/components/ui/chart";

export default function TradingChart() {
  // Mock data for portfolio performance
  const portfolioData = [
    { name: 'Jan', value: 45000 },
    { name: 'Feb', value: 52000 },
    { name: 'Mar', value: 48000 },
    { name: 'Apr', value: 61000 },
    { name: 'May', value: 58000 },
    { name: 'Jun', value: 67000 },
    { name: 'Jul', value: 73000 },
    { name: 'Aug', value: 69000 },
    { name: 'Sep', value: 85000 },
    { name: 'Oct', value: 92000 },
    { name: 'Nov', value: 118000 },
    { name: 'Dec', value: 142531 },
  ];

  const topAssets = [
    { name: 'Bitcoin', symbol: 'BTC', price: '$43,251', change: '+5.2%', color: 'orange' },
    { name: 'Ethereum', symbol: 'ETH', price: '$2,843', change: '+3.8%', color: 'blue' },
    { name: 'Solana', symbol: 'SOL', price: '$98.45', change: '+7.1%', color: 'purple' },
  ];

  return (
    <div className="mb-8">
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <CardTitle className="text-xl font-bold text-white">Mirror Trading Performance</CardTitle>
            <div className="flex space-x-2 mt-4 md:mt-0">
              <Button size="sm" className="bg-gold text-black hover:bg-gold-dark">24H</Button>
              <Button size="sm" variant="ghost" className="text-gray-400 hover:text-gold">7D</Button>
              <Button size="sm" variant="ghost" className="text-gray-400 hover:text-gold">1M</Button>
              <Button size="sm" variant="ghost" className="text-gray-400 hover:text-gold">3M</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Chart data={portfolioData} />
            </div>
            <div className="space-y-4">
              <div className="bg-dark-bg border border-dark-border rounded-lg p-4">
                <h3 className="text-lg font-semibold text-white mb-3">Top Performing Assets</h3>
                <div className="space-y-3">
                  {topAssets.map((asset, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-8 h-8 bg-${asset.color}-500 rounded-full flex items-center justify-center`}>
                          {asset.symbol === 'BTC' && (
                            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M23.638 14.904c-1.602 6.43-8.113 10.34-14.542 8.736C2.67 22.05-1.244 15.525.362 9.105 1.962 2.67 8.475-1.243 14.9.358c6.43 1.605 10.342 8.115 8.738 14.546z"/>
                            </svg>
                          )}
                          {asset.symbol === 'ETH' && (
                            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M11.944 17.97L4.58 13.62 11.943 24l7.37-10.38-7.372 4.35h.003zM12.056 0L4.69 12.223l7.365 4.354 7.365-4.35L12.056 0z"/>
                            </svg>
                          )}
                          {asset.symbol === 'SOL' && (
                            <span className="text-white text-xs font-bold">SOL</span>
                          )}
                        </div>
                        <div className="ml-3">
                          <p className="text-white font-medium">{asset.name}</p>
                          <p className="text-gray-400 text-sm">{asset.symbol}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-medium">{asset.price}</p>
                        <p className="text-green-400 text-sm">{asset.change}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-dark-bg border border-dark-border rounded-lg p-4">
                <h3 className="text-lg font-semibold text-white mb-3">Quick Actions</h3>
                <div className="space-y-2">
                  <Button className="w-full bg-gold text-black hover:bg-gold-dark">
                    Start Mirror Trading
                  </Button>
                  <Button variant="outline" className="w-full border-gold text-gold hover:bg-gold hover:text-black">
                    View All Positions
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
