import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSupportTicketSchema, type SupportTicket } from "@shared/schema";
import { z } from "zod";

const supportTicketFormSchema = insertSupportTicketSchema.extend({
  subject: z.string().min(1, "Subject is required"),
  priority: z.enum(["normal", "high", "urgent"]),
  description: z.string().min(10, "Description must be at least 10 characters"),
});

type SupportTicketForm = z.infer<typeof supportTicketFormSchema>;

export default function SupportCenter() {
  const { toast } = useToast();

  const form = useForm<SupportTicketForm>({
    resolver: zodResolver(supportTicketFormSchema),
    defaultValues: {
      subject: "",
      priority: "normal",
      description: "",
    },
  });

  const { data: supportTickets = [], isLoading } = useQuery<SupportTicket[]>({
    queryKey: ["/api/support/tickets"],
  });

  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: SupportTicketForm) => {
      await apiRequest("POST", "/api/support/tickets", ticketData);
    },
    onSuccess: () => {
      toast({
        title: "Ticket Created",
        description: "Your support ticket has been submitted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/support/tickets"] });
      form.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create support ticket. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = form.handleSubmit((data) => {
    createTicketMutation.mutate(data);
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "bg-green-500 text-white";
      case "in_progress":
        return "bg-yellow-500 text-black";
      case "open":
        return "bg-blue-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-500 text-white";
      case "high":
        return "bg-orange-500 text-white";
      case "normal":
        return "bg-blue-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  return (
    <div className="mb-8">
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-white">Support Center</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Submit a Support Ticket</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="subject" className="text-gray-400">Subject</Label>
                  <Select 
                    value={form.watch("subject")} 
                    onValueChange={(value) => form.setValue("subject", value)}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select a topic" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="Account Issues">Account Issues</SelectItem>
                      <SelectItem value="Deposit/Withdrawal">Deposit/Withdrawal</SelectItem>
                      <SelectItem value="Trading Questions">Trading Questions</SelectItem>
                      <SelectItem value="Course Access">Course Access</SelectItem>
                      <SelectItem value="Affiliate Program">Affiliate Program</SelectItem>
                      <SelectItem value="Technical Support">Technical Support</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.subject && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.subject.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="priority" className="text-gray-400">Priority</Label>
                  <Select 
                    value={form.watch("priority")} 
                    onValueChange={(value: "normal" | "high" | "urgent") => form.setValue("priority", value)}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.priority && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.priority.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="description" className="text-gray-400">Description</Label>
                  <Textarea
                    {...form.register("description")}
                    rows={4}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Please describe your issue in detail..."
                  />
                  {form.formState.errors.description && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.description.message}</p>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gold text-black hover:bg-gold-dark"
                  disabled={createTicketMutation.isPending}
                >
                  {createTicketMutation.isPending ? "Submitting..." : "Submit Ticket"}
                </Button>
              </form>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Recent Tickets</h3>
              {isLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="bg-dark-bg border border-dark-border rounded-lg p-4">
                      <div className="h-4 bg-gray-800 rounded mb-2 animate-pulse"></div>
                      <div className="h-3 bg-gray-800 rounded mb-2 animate-pulse"></div>
                      <div className="h-3 bg-gray-800 rounded w-1/2 animate-pulse"></div>
                    </div>
                  ))}
                </div>
              ) : supportTickets.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 mx-auto mb-4 bg-dark-bg rounded-full flex items-center justify-center">
                    <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">No Support Tickets</h3>
                  <p className="text-gray-400">You haven't submitted any support tickets yet.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {supportTickets.map((ticket: any) => (
                    <div key={ticket.id} className="bg-dark-bg border border-dark-border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium">
                          #{ticket.id.slice(-8)} - {ticket.subject}
                        </span>
                        <div className="flex space-x-2">
                          <Badge className={getPriorityColor(ticket.priority)}>
                            {ticket.priority}
                          </Badge>
                          <Badge className={getStatusColor(ticket.status)}>
                            {ticket.status.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-gray-400 text-sm mb-2 line-clamp-2">{ticket.description}</p>
                      <p className="text-gray-500 text-xs">
                        Created {new Date(ticket.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-6 p-4 bg-blue-500 bg-opacity-10 border border-blue-500 rounded-lg">
                <h4 className="text-blue-400 font-medium mb-2">Need Immediate Help?</h4>
                <p className="text-gray-400 text-sm mb-3">Our live chat support is available 24/7 for urgent issues.</p>
                <Button className="bg-blue-500 text-white hover:bg-blue-600">
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                  Start Live Chat
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
