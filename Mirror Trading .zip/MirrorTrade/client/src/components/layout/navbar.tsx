import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { User } from "@shared/schema";

interface NavbarProps {
  user: User;
}

export default function Navbar({ user }: NavbarProps) {
  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleNavClick = (href: string) => {
    if (href.startsWith("#")) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  };

  return (
    <nav className="bg-black border-b border-dark-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <a className="text-2xl font-bold text-gold">Mirror Trading</a>
              </Link>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                <button
                  onClick={() => handleNavClick("#dashboard")}
                  className="text-gold px-3 py-2 rounded-md text-sm font-medium"
                >
                  Dashboard
                </button>
                <button
                  onClick={() => handleNavClick("#trading")}
                  className="text-gray-300 hover:text-gold px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  Trading
                </button>
                <button
                  onClick={() => handleNavClick("#courses")}
                  className="text-gray-300 hover:text-gold px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  Courses
                </button>
                <button
                  onClick={() => handleNavClick("#affiliate")}
                  className="text-gray-300 hover:text-gold px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  Affiliate
                </button>
                <button
                  onClick={() => handleNavClick("#support")}
                  className="text-gray-300 hover:text-gold px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  Support
                </button>
                {user?.isAdmin && (
                  <Link href="/admin">
                    <a className="text-gray-300 hover:text-gold px-3 py-2 rounded-md text-sm font-medium transition-colors">
                      Admin
                    </a>
                  </Link>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <button className="text-gray-300 hover:text-gold transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5 5l-5-5h5v-5a7.5 7.5 0 0 1 7.5-7.5v3a4.5 4.5 0 0 0-4.5 4.5v5z" />
              </svg>
            </button>
            <div className="relative">
              <div className="flex items-center space-x-2">
                <img
                  className="h-8 w-8 rounded-full object-cover"
                  src={
                    user.profileImageUrl ||
                    `https://ui-avatars.com/api/?name=${user.firstName}+${user.lastName}&background=FFD700&color=000000`
                  }
                  alt="User profile"
                />
                <span className="hidden md:block text-gray-300">
                  {user.firstName} {user.lastName}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="text-gray-300 hover:text-gold"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
